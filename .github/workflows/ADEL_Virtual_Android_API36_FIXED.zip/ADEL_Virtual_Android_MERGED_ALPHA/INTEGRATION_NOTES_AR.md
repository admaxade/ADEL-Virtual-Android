# ADEL Virtual Android — VineOS connected alpha

- VineOS remains the Android application module and native runtime.
- The ADEL Java screen is copied into the VineOS app and is the launcher activity.
- “تشغيل آخر نظام افتراضي” calls `ADELVMBridge.startMostRecent()`, which reads the most recently used VM from `InstanceRepository` and invokes `VineVMManager.startInstance()`.
- “إنشاء / إدارة الأنظمة الافتراضية” opens the original VineOS management UI to import a `.vrom` and create an instance.

## Important runtime limitations
This is a source-level integration, not proof that an Android guest boots successfully. A compatible `.vrom`, working native `libvine_runtime.so`, required QEMU/runtime assets, and host permissions are still required. The bridge reports missing VM, timeout, or native runtime errors instead of showing a fake success message. Build and test on a real device before treating guest boot as supported.
