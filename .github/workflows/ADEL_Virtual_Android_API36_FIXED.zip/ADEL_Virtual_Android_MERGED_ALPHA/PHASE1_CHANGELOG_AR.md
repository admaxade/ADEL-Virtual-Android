# تقرير المرحلة الأولى — ADEL Virtual Android

## التعديلات المنفذة في المصدر
- إضافة `VromProvisioner.kt` لفحص ملف RootFS المضغوط واستخراجه إلى مجلد مرحلي قبل نشره داخل `instances/<uuid>/rootfs`.
- فحص جميع عناصر TAR في مرور أول قبل كتابة ملفات RootFS: رفض المسارات المطلقة/المتجاوزة، العناصر الخاصة، التكرارات، الأحجام السالبة، وتجاوز حد التخزين.
- فحص الروابط الرمزية والصلبة. الروابط الرمزية المطلقة داخل نظام الضيف يعاد إنشاؤها كروابط نسبية محصورة داخل RootFS؛ الروابط التي تتجاوز الجذر تُرفض. تُنشأ الروابط بعد الملفات العادية لتجنب الكتابة عبر رابط مزروع.
- الحفاظ على بتات الصلاحيات باستخدام `Os.chmod`، ودعم روابط symlink وhardlink.
- إضافة `engineType` و`rootfsEntry` كحقول اختيارية ذات قيم افتراضية في `ROMImage` ووصف VROM، دون تغيير كيان Room أو إصدار قاعدة البيانات.
- توليد UUID قبل استدعاء `VineRuntime.createInstance()`، وعدم حفظ VMInstance إلا بعد نجاح التجهيز.
- حذف مجلد الجهاز إذا فشل التجهيز أو حفظ السجل.
- كتابة `engine.conf` داخل مجلد الجهاز.
- منع تمرير Instance ذات `engineType=proot` إلى محرك Namespace الحالي؛ إذ لم يتم دمج PRoot التنفيذي بعد.

## تنسيق VROM المتوقع لمسار Linux
يجب أن يحتوي ZIP على `manifest.json` في الجذر، وأن يتضمن على الأقل:

```json
{
  "displayName": "Linux RootFS",
  "androidVersion": "Linux",
  "apiLevel": 1,
  "supportedAbis": ["arm64-v8a"],
  "has32BitSupport": false,
  "releaseDate": "2026-11-27",
  "engineType": "proot",
  "rootfsEntry": "rootfs.tar.gz"
}
```

ويجب أن يحتوي الأرشيف على `rootfs.tar.gz` (أو المسار المحدد في `rootfsEntry`) بصيغة TAR+GZIP.

## حدود المرحلة
- هذه المرحلة تجهز RootFS فقط؛ لا تشغل Linux بعد.
- لم تتم إضافة PRoot أو loader، ولم يتم تعديل محرك VineOS/Namespace الأصلي.
- يتطلب تشغيل Linux تنفيذ المرحلة الثانية ودمج PRoot الحقيقي واختباره على الجهاز.

## التحقق
- تم التحقق من سلامة ZIP الناتج وبنية XML/JSON النصية ووجود الملفات المعدلة.
- جرت محاولة تشغيل Gradle compile، لكنها توقفت قبل بدء البناء لأن بيئة التنفيذ لم تتمكن من الوصول إلى `services.gradle.org` لتنزيل Gradle 9.7.1 (`UnknownHostException`). لذلك لا يوجد ادعاء بنجاح بناء Kotlin/APK أو اختبار على الهاتف.
