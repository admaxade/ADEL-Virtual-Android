# ADEL Virtual Android — API 36 Ready Source

تم تجهيز نسخة المصدر لتستهدف Android SDK 36 في مشروع VineOS الرئيسي.

## التغييرات
- `compileSdk = 36`
- `targetSdk = 36`
- الحفاظ على بقية إعدادات التطبيق ومكونات VineOS كما هي.
- إرفاق ملف `GITHUB_WORKFLOW_BUILD.yml` كمرجع جاهز لبناء APK باستخدام GitHub Actions وSDK 36 وBuild Tools 36.0.0.

## ملاحظة
هذه حزمة مصدر معدلة وليست APK مبنيًا. لم يتم تشغيل بناء Gradle في هذه البيئة، لذلك يجب التحقق من نتيجة GitHub Actions. نجاح بناء APK لا يثبت وحده أن صورة Android Guest تقلع فعليًا؛ يلزم اختبار ROM ومكونات QEMU/Native على جهاز حقيقي.
