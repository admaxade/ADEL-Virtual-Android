package com.hexadecinull.vineos.data.repository

import android.system.Os
import com.hexadecinull.vineos.data.models.ROMImage
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.zip.ZipFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream

/** Safely provisions a Linux rootfs from a .vrom ZIP containing a gzip-compressed tar. */
class VromProvisioner {
    suspend fun provision(rom: ROMImage, instanceDir: File, storageMb: Int): Result<File> =
        withContext(Dispatchers.IO) {
            runCatching {
                require(rom.engineType.equals("proot", ignoreCase = true)) {
                    "ROM engineType is not proot"
                }
                val archivePath = rom.rootfsEntry ?: DEFAULT_ROOTFS_ENTRY
                validateArchiveEntryName(archivePath)
                val vrom = File(rom.localPath ?: error("ROM file is not downloaded"))
                require(vrom.isFile) { "VROM file not found" }
                require(storageMb > 0) { "Invalid storage limit" }

                val root = File(instanceDir, "rootfs")
                val staging = File(instanceDir, "rootfs.staging")
                val tarFile = File(instanceDir, "rootfs.tar.gz")
                deleteRecursively(staging)
                deleteRecursively(root)
                tarFile.delete()
                require(staging.mkdirs()) { "Cannot create temporary rootfs directory" }

                try {
                    extractZipEntry(vrom, archivePath, tarFile)
                    val maxBytes = storageMb.toLong() * 1024L * 1024L
                    inspectTar(tarFile, maxBytes)
                    extractTarSafely(tarFile, staging, maxBytes)
                    require(hasShellOrInit(staging)) {
                        "RootFS is missing a supported shell or init executable (bin/sh, usr/bin/sh, system/bin/sh, init)"
                    }
                    require(rootfsSize(staging) <= maxBytes) { "Extracted RootFS exceeds the selected storage limit" }

                    // Publish only after the complete staged tree passed validation.
                    if (root.exists()) deleteRecursively(root)
                    if (!staging.renameTo(root)) throw IOException("Could not publish the prepared RootFS")
                    tarFile.delete()
                    File(instanceDir, "engine.conf").writeText(
                        "engineType=proot\nrootfsEntry=$archivePath\nformat=1\n",
                        Charsets.UTF_8,
                    )
                    root
                } catch (t: Throwable) {
                    deleteRecursively(staging)
                    deleteRecursively(root)
                    tarFile.delete()
                    throw t
                }
            }
        }

    private fun extractZipEntry(vrom: File, entryName: String, output: File) {
        ZipFile(vrom).use { zip ->
            val entry = zip.getEntry(entryName) ?: error("VROM does not contain $entryName")
            require(!entry.isDirectory) { "RootFS archive entry is a directory" }
            require(entry.size in 1..MAX_COMPRESSED_BYTES) { "Compressed RootFS archive has an invalid or excessive size" }
            zip.getInputStream(entry).use { input ->
                FileOutputStream(output).use { out ->
                    val buffer = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        total += n
                        require(total <= MAX_COMPRESSED_BYTES) { "Compressed RootFS archive exceeds safety limit" }
                        out.write(buffer, 0, n)
                    }
                }
            }
        }
    }

    /** First pass: validate every member before creating any extracted member. */
    private fun inspectTar(tarFile: File, maxBytes: Long) {
        val seen = HashSet<String>()
        var total = 0L
        openTar(tarFile).use { tar ->
            while (true) {
                val entry = tar.nextTarEntry ?: break
                val name = normalizeMemberName(entry.name)
                if (name == ".") {
                    require(entry.isDirectory) { "Root TAR entry must be a directory" }
                    drainCurrentEntry(tar)
                    continue
                }
                require(seen.add(name)) { "Duplicate TAR path: $name" }
                require(entry.size >= 0) { "Negative TAR member size" }
                if (entry.isFile) {
                    total = Math.addExact(total, entry.size)
                    require(total <= maxBytes && total <= MAX_UNPACKED_BYTES) {
                        "RootFS contents exceed the selected storage limit"
                    }
                }
                when {
                    entry.isDirectory || entry.isFile -> Unit
                    entry.isSymbolicLink -> validateLink(name, entry.linkName, false)
                    entry.isLink -> validateLink(name, entry.linkName, true)
                    else -> error("Unsupported special TAR entry: $name")
                }
                // Drain the current member so the next header is reached reliably.
                drainCurrentEntry(tar)
            }
        }
    }

    /** Second pass: regular files/directories first, links last to prevent link-following writes. */
    private fun extractTarSafely(tarFile: File, destination: File, maxBytes: Long) {
        val links = mutableListOf<TarLink>()
        val directories = mutableListOf<Pair<File, Int>>()
        var total = 0L
        openTar(tarFile).use { tar ->
            while (true) {
                val entry = tar.nextTarEntry ?: break
                val name = normalizeMemberName(entry.name)
                if (name == ".") {
                    require(entry.isDirectory) { "Root TAR entry must be a directory" }
                    drainCurrentEntry(tar)
                    continue
                }
                val target = safeChild(destination, name)
                when {
                    entry.isDirectory -> {
                        ensureDirectory(destination, target)
                        directories += target to entry.mode
                    }
                    entry.isFile -> {
                        total = Math.addExact(total, entry.size)
                        require(total <= maxBytes && total <= MAX_UNPACKED_BYTES) { "RootFS exceeds storage limit" }
                        ensureDirectory(destination, target.parentFile ?: destination)
                        require(!target.exists() && !target.isDirectory) { "Conflicting TAR path: $name" }
                        FileOutputStream(target).use { out ->
                            val buffer = ByteArray(64 * 1024)
                            var copied = 0L
                            while (true) {
                                val n = tar.read(buffer)
                                if (n < 0) break
                                copied += n
                                require(copied <= entry.size && copied <= maxBytes) { "Invalid TAR member size: $name" }
                                out.write(buffer, 0, n)
                            }
                            require(copied == entry.size) { "Truncated TAR member: $name" }
                        }
                        applyMode(target, entry.mode)
                    }
                    entry.isSymbolicLink -> links += TarLink(name, entry.linkName, false)
                    entry.isLink -> links += TarLink(name, entry.linkName, true)
                    else -> error("Unsupported TAR entry: $name")
                }
                if (!entry.isFile) drainCurrentEntry(tar)
            }
        }

        // All link targets are checked again immediately before creation.
        links.filterNot { it.hard }.forEach { link ->
            val linkFile = safeChild(destination, link.name)
            ensureDirectory(destination, linkFile.parentFile ?: destination)
            val target = resolveLinkTarget(destination, link.name, link.target, false)
            require(!linkFile.exists() && !linkFile.isDirectory) { "Conflicting symlink path: ${link.name}" }
            val relativeTarget = linkFile.parentFile.toPath().relativize(target.toPath())
            java.nio.file.Files.createSymbolicLink(linkFile.toPath(), relativeTarget)
        }
        links.filter { it.hard }.forEach { link ->
            val linkFile = safeChild(destination, link.name)
            ensureDirectory(destination, linkFile.parentFile ?: destination)
            val target = resolveLinkTarget(destination, link.name, link.target, true)
            require(target.isFile) { "Hard-link target is missing: ${link.target}" }
            require(!linkFile.exists()) { "Conflicting hard-link path: ${link.name}" }
            java.nio.file.Files.createLink(linkFile.toPath(), target.toPath())
        }
        directories.sortedByDescending { it.first.path.length }.forEach { (dir, mode) -> applyMode(dir, mode) }
    }

    private fun openTar(file: File): TarArchiveInputStream = TarArchiveInputStream(
        GzipCompressorInputStream(BufferedInputStream(FileInputStream(file))),
    )

    private fun drainCurrentEntry(tar: TarArchiveInputStream) {
        val buffer = ByteArray(32 * 1024)
        while (tar.read(buffer) != -1) { /* consume member before advancing */ }
    }

    private fun normalizeMemberName(raw: String): String {
        require(raw.isNotBlank() && !raw.startsWith('/') && !raw.startsWith('\\')) { "Absolute or empty TAR path" }
        val normalized = raw.removePrefix("./").trimEnd('/')
        if (normalized.isBlank() || normalized == ".") return "."
        val parts = normalized.split('/')
        require(parts.none { it.isEmpty() || it == "." || it == ".." }) { "Unsafe TAR path: $raw" }
        return parts.joinToString("/")
    }

    private fun validateArchiveEntryName(name: String) {
        require(name.isNotBlank() && !name.startsWith('/') && name.split('/').none { it == ".." || it.isEmpty() }) {
            "Unsafe rootfsEntry path"
        }
    }

    private fun validateLink(member: String, rawTarget: String, hard: Boolean) {
        require(rawTarget.isNotBlank() && !rawTarget.startsWith('\\')) {
            "Invalid link target in TAR: $member"
        }
        require(!hard || !rawTarget.startsWith('/')) { "Absolute hard-link target in TAR: $member" }
        resolveLinkPath(member, rawTarget, hard)
    }

    private fun resolveLinkPath(member: String, rawTarget: String, hard: Boolean): String {
        // Absolute symlinks in a guest rootfs are rooted at the guest root. Recreate
        // them as relative links so they cannot point at the Android host filesystem.
        val absoluteGuestPath = !hard && rawTarget.startsWith('/')
        val base = if (hard || absoluteGuestPath) emptyList() else member.split('/').dropLast(1)
        val stack = base.toMutableList()
        rawTarget.trimStart('/').split('/').forEach { part ->
            when (part) {
                "", "." -> Unit
                ".." -> {
                    require(stack.isNotEmpty()) { "Link escapes RootFS: $member -> $rawTarget" }
                    stack.removeAt(stack.lastIndex)
                }
                else -> stack += part
            }
        }
        require(stack.isNotEmpty()) { "Invalid link target: $member -> $rawTarget" }
        return stack.joinToString("/")
    }

    private fun resolveLinkTarget(root: File, member: String, rawTarget: String, hard: Boolean): File =
        safeChild(root, resolveLinkPath(member, rawTarget, hard))

    private fun safeChild(root: File, relative: String): File {
        val canonicalRoot = root.canonicalFile
        val child = File(root, relative).canonicalFile
        require(child.path == canonicalRoot.path || child.path.startsWith(canonicalRoot.path + File.separator)) { "Path escapes RootFS: $relative" }
        return child
    }

    private fun ensureDirectory(root: File, dir: File) {
        val safe = dir.canonicalFile
        val canonicalRoot = root.canonicalFile
        require(safe.path == canonicalRoot.path || safe.path.startsWith(canonicalRoot.path + File.separator)) {
            "Directory escapes RootFS"
        }
        if (dir.exists()) require(dir.isDirectory && !java.nio.file.Files.isSymbolicLink(dir.toPath())) {
            "Unexpected non-directory or symlink in extraction path: $dir"
        } else require(dir.mkdirs()) { "Cannot create directory: $dir" }
    }

    private fun hasShellOrInit(root: File): Boolean = listOf(
        "bin/sh", "usr/bin/sh", "system/bin/sh", "init",
    ).any { relative ->
        val f = File(root, relative)
        f.exists() && (f.isFile || java.nio.file.Files.isSymbolicLink(f.toPath()))
    }

    private fun rootfsSize(root: File): Long {
        var total = 0L
        root.walkTopDown().forEach { file ->
            if (file.isFile && !java.nio.file.Files.isSymbolicLink(file.toPath())) {
                total = Math.addExact(total, file.length())
            }
        }
        return total
    }

    private fun applyMode(file: File, mode: Int) {
        // Preserve Unix permission bits; Android's Os.chmod accepts the low 07777 bits.
        Os.chmod(file.absolutePath, mode and 0xFFF)
    }

    private fun deleteRecursively(file: File) {
        if (!file.exists() && !java.nio.file.Files.isSymbolicLink(file.toPath())) return
        if (file.isDirectory && !java.nio.file.Files.isSymbolicLink(file.toPath())) file.listFiles()?.forEach(::deleteRecursively)
        file.delete()
    }

    private data class TarLink(val name: String, val target: String, val hard: Boolean)

    companion object {
        private const val DEFAULT_ROOTFS_ENTRY = "rootfs.tar.gz"
        private const val MAX_COMPRESSED_BYTES = 1024L * 1024L * 1024L
        private const val MAX_UNPACKED_BYTES = 16L * 1024L * 1024L * 1024L
    }
}
