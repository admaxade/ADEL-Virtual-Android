# ADEL Virtual Android — API 37 Ready Source

تم تجهيز نسخة المصدر لتستهدف Android SDK 37 في مشروع VineOS الرئيسي.

## التغييرات
- `compileSdk = 37`  (مطلوب بسبب Compose BOM 2026.08 + AGP 9.3.2)
- `targetSdk = 36`
- ملف `.github/workflows/build.yml` محدّث ليبني باستخدام SDK 37 و Build Tools 36.0.0 مع كشف تلقائي لـ compileSdk.

## ملاحظة
هذه حزمة مصدر معدلة وليست APK مبنيًا. نجاح بناء APK لا يثبت وحده أن صورة Android Guest تقلع فعليًا؛ يلزم اختبار ROM ومكونات QEMU/Native على جهاز حقيقي.
