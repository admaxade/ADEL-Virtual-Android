package com.adel.virtualandroid;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER);
        page.setPadding(dp(24), dp(24), dp(24), dp(24));
        page.setBackgroundColor(0xFFF4F6FA);

        TextView title = new TextView(this);
        title.setText("ADEL Virtual Android");
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(0xFF17233B);
        title.setGravity(Gravity.CENTER);

        TextView status = new TextView(this);
        status.setText("تم إنشاء التطبيق بنجاح\n\nهذه نسخة تأسيسية. محرك النظام الافتراضي لم يُدمج بعد.");
        status.setTextSize(17);
        status.setTextColor(0xFF43516A);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(20), 0, dp(20));

        page.addView(title, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        page.addView(status, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        setContentView(page);
    }
}
