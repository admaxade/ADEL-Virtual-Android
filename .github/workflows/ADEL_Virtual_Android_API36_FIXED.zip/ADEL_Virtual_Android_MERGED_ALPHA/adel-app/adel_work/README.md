# ADEL Virtual Android — Version 0.2.0

نسخة تطويرية بواجهة لوحة تحكم عربية للأقسام الأساسية في مشروع ADEL Virtual Android.

## البناء عبر GitHub Actions
1. ارفع محتويات هذا المجلد إلى جذر مستودع GitHub، مع مجلد `.github`.
2. افتح تبويب Actions.
3. شغّل `Build ADEL Virtual Android APK` أو انتظر البناء التلقائي بعد Push إلى `main`.
4. نزّل APK من قسم Artifacts.

## الحالة الحالية
- واجهة لوحة تحكم عربية.
- أقسام الأجهزة الافتراضية وصور Android ومدير الملفات وMagisk وTerminal.
- توضح الواجهة أن هذه الأقسام واجهات تمهيدية وليست وظائف مكتملة.
- لا يتضمن هذا الإصدار محرك Android Guest أو Root أو Magisk فعليًا.

## متطلبات البناء
- Java 17
- Android SDK Platform 35
- Gradle 8.9
- الحد الأدنى لتشغيل التطبيق المضيف: Android 8.0 (API 26)
