# ADEL Virtual Android — Clean Starter

مشروع تأسيسي لتطبيق Android باسم ADEL Virtual Android.

## البناء عبر GitHub Actions
1. أنشئ مستودع GitHub باسم `ADEL-Virtual-Android`.
2. ارفع **محتويات** هذا المجلد إلى جذر المستودع، بما في ذلك مجلد `.github`.
3. افتح تبويب Actions وشغّل `Build ADEL Virtual Android APK`.
4. بعد نجاح التشغيل، نزّل APK من قسم Artifacts.

## ملاحظات
- المشروع يستخدم Java فقط؛ لا يوجد ملف MainActivity.kt.
- يوجد ملف Gradle واحد لكل مستوى: `settings.gradle` و`build.gradle` و`app/build.gradle`.
- هذه نسخة تأسيسية، ولا تحتوي بعد على Android Guest VM أو Magisk.
- `minSdk 26` يعني أن التطبيق يستهدف Android 8.0 فما فوق كتطبيق مضيف؛ ولا يضمن توافق محرك افتراضي مستقبلي مع كل الأجهزة.
