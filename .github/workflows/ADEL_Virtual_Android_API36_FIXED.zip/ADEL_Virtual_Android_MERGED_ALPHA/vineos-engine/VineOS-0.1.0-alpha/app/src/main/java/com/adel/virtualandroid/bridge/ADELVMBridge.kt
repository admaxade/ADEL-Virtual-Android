package com.adel.virtualandroid.bridge

import android.os.Handler
import android.os.Looper
import com.adel.virtualandroid.MainActivity
import com.hexadecinull.vineos.data.models.VMStatus
import com.hexadecinull.vineos.data.repository.InstanceRepository
import com.hexadecinull.vineos.domain.VineVMManager
import dagger.hilt.android.scopes.ActivityRetainedScoped
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.launch

/** Java-facing adapter between the ADEL screen and VineOS VM manager. */
@ActivityRetainedScoped
class ADELVMBridge @Inject constructor(
    private val instances: InstanceRepository,
    private val vmManager: VineVMManager,
) {
    fun interface Callback { fun onResult(success: Boolean, message: String) }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val main = Handler(Looper.getMainLooper())

    fun startMostRecent(callback: Callback) {
        scope.launch {
            val result = runCatching {
                val instance = instances.observeAll().first()
                    .maxByOrNull { it.lastUsedAt }
                    ?: error("لا يوجد جهاز افتراضي. افتح قسم إنشاء / إدارة الأنظمة وأنشئ جهازًا وصورة ROM أولاً.")

                if (instance.storagePath.isBlank()) error("مسار تخزين الجهاز الافتراضي غير محدد.")
                vmManager.startInstance(instance)
                val terminal = withTimeoutOrNull(120_000L) {
                    vmManager.statusFlow(instance.id).first { it == VMStatus.RUNNING || it == VMStatus.ERROR }
                }
                when (terminal) {
                    VMStatus.RUNNING -> "بدأ محرك VineOS تشغيل الجهاز: ${instance.name}"
                    VMStatus.ERROR -> error("أبلغ محرك VineOS عن خطأ أثناء بدء التشغيل. راجع سجل التشخيص وتأكد من وجود صورة ROM صالحة.")
                    else -> error("لم يؤكد المحرك اكتمال بدء التشغيل خلال 120 ثانية. قد تكون صورة النظام أو متطلبات التشغيل غير مكتملة.")
                }
            }
            main.post {
                result.fold(
                    onSuccess = { callback.onResult(true, it) },
                    onFailure = { callback.onResult(false, it.message ?: "حدث خطأ غير معروف أثناء التشغيل.") },
                )
            }
        }
    }
}
