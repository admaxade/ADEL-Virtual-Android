package com.adel.virtualandroid;

import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;

import com.adel.virtualandroid.bridge.ADELVMBridge;

import dagger.hilt.android.AndroidEntryPoint;
import javax.inject.Inject;
import android.app.AlertDialog;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

@AndroidEntryPoint
public class MainActivity extends Activity {
    @Inject ADELVMBridge vmBridge;
    private TextView engineState;
    private Button startButton;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final int navy = 0xFF17233B;
    private final int muted = 0xFF68758B;
    private final int blue = 0xFF315EAB;
    private final int pageColor = 0xFFF3F6FB;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable shape(int color, int radius, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (strokeColor != 0) d.setStroke(dp(1), strokeColor);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private void space(LinearLayout parent, int height) {
        View v = new View(this);
        parent.addView(v, new LinearLayout.LayoutParams(1, dp(height)));
    }

    private void showInfo(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("حسنًا", null)
                .show();
    }

    private void addSectionTitle(LinearLayout parent, String title, String subtitle) {
        TextView t = text(title, 19, navy, true);
        parent.addView(t);
        if (subtitle != null) {
            TextView s = text(subtitle, 13, muted, false);
            s.setPadding(0, dp(4), 0, 0);
            parent.addView(s);
        }
        space(parent, 12);
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout c = column();
        c.setPadding(dp(16), dp(15), dp(16), dp(15));
        c.setBackground(shape(0xFFFFFFFF, 18, 0xFFE3E9F2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(12);
        parent.addView(c, lp);
        return c;
    }

    private void addAction(LinearLayout parent, String title, String description, String dialogTitle, String dialogMessage) {
        LinearLayout c = card(parent);
        c.addView(text(title, 16, navy, true));
        TextView d = text(description, 13, muted, false);
        d.setPadding(0, dp(5), 0, dp(12));
        c.addView(d);
        Button b = new Button(this);
        b.setText("فتح القسم");
        b.setTextColor(blue);
        b.setAllCaps(false);
        b.setBackground(shape(0xFFEAF0FA, 12, 0));
        b.setOnClickListener(v -> showInfo(dialogTitle, dialogMessage));
        c.addView(b, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(46)));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(pageColor);

        LinearLayout root = column();
        root.setPadding(dp(20), dp(24), dp(20), dp(28));
        scroll.addView(root);

        LinearLayout header = column();
        header.setPadding(dp(19), dp(20), dp(19), dp(20));
        header.setBackground(shape(navy, 22, 0));
        root.addView(header);

        TextView brand = text("ADEL Virtual Android", 23, 0xFFFFFFFF, true);
        header.addView(brand);
        TextView tagline = text("بيئة Android افتراضية داخل هاتفك", 14, 0xFFDCE6F7, false);
        tagline.setPadding(0, dp(7), 0, dp(17));
        header.addView(tagline);

        TextView badge = text("●  الإصدار 0.2.0  |  الواجهة الأساسية", 12, 0xFFFFFFFF, true);
        badge.setPadding(dp(11), dp(8), dp(11), dp(8));
        badge.setBackground(shape(0xFF304565, 30, 0));
        header.addView(badge, new LinearLayout.LayoutParams(-2, -2));

        space(root, 22);
        addSectionTitle(root, "لوحة التحكم", "إدارة مكونات ADEL Virtual Android من مكان واحد");

        LinearLayout status = card(root);
        status.addView(text("حالة المحرك الافتراضي", 16, navy, true));
        TextView state = text("محرك VineOS مدمج؛ لم يتم التحقق من تشغيل ضيف بعد", 15, 0xFFB66A16, true);
        engineState = state;
        state.setPadding(0, dp(8), 0, dp(5));
        status.addView(state);
        status.addView(text("هذه النسخة تحتوي على واجهة الإدارة فقط. لم يتم تشغيل نظام Android ضيف بعد.", 13, muted, false));

        Button launch = new Button(this);
        launch.setText("تشغيل آخر نظام افتراضي");
        launch.setAllCaps(false);
        launch.setOnClickListener(v -> {
            launch.setEnabled(false);
            engineState.setText("جارٍ طلب تشغيل النظام الافتراضي...");
            vmBridge.startMostRecent(new ADELVMBridge.Callback() {
                @Override public void onResult(boolean success, String message) {
                    launch.setEnabled(true);
                    engineState.setText(message);
                    showInfo(success ? "حالة النظام الافتراضي" : "تعذر التشغيل", message);
                }
            });
        });
        root.addView(launch, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));

        Button manage = new Button(this);
        manage.setText("إنشاء / إدارة الأنظمة الافتراضية");
        manage.setAllCaps(false);
        manage.setOnClickListener(v -> startActivity(new Intent(this, com.hexadecinull.vineos.MainActivity.class)));
        root.addView(manage, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));

        addSectionTitle(root, "إدارة النظام", "إدارة الصور والأجهزة الافتراضية من واجهة VineOS");
        addAction(root, "الأجهزة الافتراضية", "إنشاء الأجهزة الافتراضية وتشغيلها وإيقافها.",
                "الأجهزة الافتراضية", "استخدم زر إنشاء / إدارة الأنظمة الافتراضية لفتح مدير VineOS. بعد إنشاء جهاز افتراضي وصورة نظام متوافقة، ارجع واضغط تشغيل آخر نظام افتراضي.");
        addAction(root, "صور أنظمة Android", "استيراد وإدارة ملفات صور النظام ROM.",
                "صور أنظمة Android", "سيتم إضافة مستورد صور النظام والتحقق من ملفات ROM في مرحلة لاحقة.");
        addAction(root, "مدير الملفات", "استعراض ملفات البيئة الافتراضية وإدارتها.",
                "مدير الملفات", "مدير الملفات الفعلي وصلاحيات Root داخل النظام الضيف لم تتم إضافتهما بعد.");
        addAction(root, "Magisk وإضافاته", "إدارة Root وMagisk Modules داخل النظام الضيف.",
                "Magisk", "لم يتم دمج Magisk أو Zygisk أو نظام تثبيت Modules بعد.");
        addAction(root, "Terminal", "واجهة أوامر للنظام الافتراضي.",
                "Terminal", "سيتم ربط الطرفية ببيئة النظام الضيف بعد دمج المحرك.");
        addAction(root, "معلومات التطبيق", "الإصدار ومتطلبات التشغيل وملاحظات المشروع.",
                "حول ADEL Virtual Android", "الإصدار: 0.2.0\nاسم الحزمة: com.adel.virtualandroid\nالحد الأدنى للمضيف: Android 8.0 (API 26)\n\nهذه نسخة واجهة تأسيسية وليست محرك افتراضية مكتملًا.");

        TextView footer = text("ADEL Virtual Android  •  مشروع قيد التطوير", 12, muted, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(10), 0, dp(4));
        root.addView(footer);

        setContentView(scroll);
    }
}
